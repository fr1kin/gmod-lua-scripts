
print( "loaded menu side lua" );

print( "using haks .... tace some RICs!!!" );










